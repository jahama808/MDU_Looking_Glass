#!/usr/bin/env python3
"""
Property Outage Analysis Script - Database Version

This script processes WAN connectivity outage data and Eero discovery details
and stores the results in a SQLite database for use by a web application.

Usage:
    python process_property_outages_db.py --connectivity-file <path> --discovery-file <path> [--database <path>]

Example:
    python process_property_outages_db.py \\
        --connectivity-file wan_connectivity-2025-11-06.csv \\
        --discovery-file Eero_Discovery_Details_-_2025-11-04_081045.csv \\
        --database outages.db
"""

import pandas as pd
import argparse
import os
import sys
import sqlite3
from datetime import datetime
from pathlib import Path


# Check if running in virtual environment
def check_venv():
    """Check if script is running in a virtual environment."""
    if not (hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)):
        print("⚠️  WARNING: Not running in a virtual environment!")
        print("   It's recommended to run this script in a venv.")
        print("   Run: source venv/bin/activate  (or venv\\Scripts\\activate on Windows)")
        print()
        response = input("Continue anyway? (y/N): ")
        if response.lower() != 'y':
            print("Exiting...")
            sys.exit(0)
        print()


def validate_file(filepath, file_type):
    """Validate that the file exists and is readable."""
    if not os.path.exists(filepath):
        print(f"Error: {file_type} file not found: {filepath}")
        sys.exit(1)
    
    if not os.path.isfile(filepath):
        print(f"Error: {file_type} path is not a file: {filepath}")
        sys.exit(1)
    
    try:
        with open(filepath, 'r') as f:
            pass
    except Exception as e:
        print(f"Error: Cannot read {file_type} file: {e}")
        sys.exit(1)


def create_database_schema(conn):
    """Create the database schema."""
    cursor = conn.cursor()
    
    # Properties table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS properties (
            property_id INTEGER PRIMARY KEY AUTOINCREMENT,
            property_name TEXT UNIQUE NOT NULL,
            total_networks INTEGER,
            total_outages INTEGER,
            last_updated TIMESTAMP
        )
    """)
    
    # Networks table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS networks (
            network_id INTEGER PRIMARY KEY,
            property_id INTEGER,
            street_address TEXT,
            subloc TEXT,
            customer_name TEXT,
            total_outages INTEGER,
            FOREIGN KEY (property_id) REFERENCES properties(property_id)
        )
    """)
    
    # Hourly aggregated outages by property
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS property_hourly_outages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            property_id INTEGER,
            outage_hour TIMESTAMP,
            total_outage_count INTEGER,
            FOREIGN KEY (property_id) REFERENCES properties(property_id),
            UNIQUE(property_id, outage_hour)
        )
    """)
    
    # Hourly outages by network
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS network_hourly_outages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            network_id INTEGER,
            outage_hour TIMESTAMP,
            outage_count INTEGER,
            FOREIGN KEY (network_id) REFERENCES networks(network_id),
            UNIQUE(network_id, outage_hour)
        )
    """)
    
    # Raw outages table (for detailed analysis)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS outages (
            outage_id INTEGER PRIMARY KEY AUTOINCREMENT,
            network_id INTEGER,
            wan_down_start TIMESTAMP,
            wan_down_end TIMESTAMP,
            duration REAL,
            reason TEXT,
            FOREIGN KEY (network_id) REFERENCES networks(network_id)
        )
    """)
    
    # Create indexes for better query performance
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_networks_property ON networks(property_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_property_hourly_property ON property_hourly_outages(property_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_property_hourly_hour ON property_hourly_outages(outage_hour)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_network_hourly_network ON network_hourly_outages(network_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_network_hourly_hour ON network_hourly_outages(outage_hour)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_outages_network ON outages(network_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_outages_start ON outages(wan_down_start)")
    
    conn.commit()
    print("✓ Database schema created")


def clear_existing_data(conn):
    """Clear existing data from all tables."""
    cursor = conn.cursor()
    cursor.execute("DELETE FROM outages")
    cursor.execute("DELETE FROM network_hourly_outages")
    cursor.execute("DELETE FROM property_hourly_outages")
    cursor.execute("DELETE FROM networks")
    cursor.execute("DELETE FROM properties")
    conn.commit()
    print("✓ Existing data cleared")


def process_outages_to_db(connectivity_file, discovery_file, database_path):
    """Process the outage data and store in database."""
    
    print(f"\n{'='*60}")
    print("PROPERTY OUTAGE ANALYSIS - DATABASE VERSION")
    print(f"{'='*60}\n")
    
    # Read the source files
    print(f"Reading connectivity file: {connectivity_file}")
    try:
        wan_connectivity = pd.read_csv(connectivity_file)
        print(f"  ✓ Loaded {len(wan_connectivity):,} WAN connectivity records")
    except Exception as e:
        print(f"  ✗ Error reading connectivity file: {e}")
        sys.exit(1)
    
    print(f"\nReading discovery file: {discovery_file}")
    try:
        eero_details = pd.read_csv(discovery_file)
        print(f"  ✓ Loaded {len(eero_details):,} Eero discovery records")
    except Exception as e:
        print(f"  ✗ Error reading discovery file: {e}")
        sys.exit(1)
    
    # Validate required columns
    required_wan_cols = ['network_id', 'wan_down_start', 'wan_down_end', 'duration', 'reason']
    required_eero_cols = ['MDU Name', 'Eero Network ID', 'Street Address', 'Subloc', 'Customer Name']
    
    missing_wan_cols = [col for col in required_wan_cols if col not in wan_connectivity.columns]
    missing_eero_cols = [col for col in required_eero_cols if col not in eero_details.columns]
    
    if missing_wan_cols:
        print(f"\n✗ Error: Connectivity file missing required columns: {missing_wan_cols}")
        sys.exit(1)
    
    if missing_eero_cols:
        print(f"\n✗ Error: Discovery file missing required columns: {missing_eero_cols}")
        sys.exit(1)
    
    # Convert timestamps to datetime
    print("\nProcessing timestamps...")
    try:
        wan_connectivity['wan_down_start'] = pd.to_datetime(wan_connectivity['wan_down_start'])
        wan_connectivity['wan_down_end'] = pd.to_datetime(wan_connectivity['wan_down_end'])
        print("  ✓ Timestamps converted")
    except Exception as e:
        print(f"  ✗ Error converting timestamps: {e}")
        sys.exit(1)
    
    # Extract hour from start time for grouping
    wan_connectivity['outage_hour'] = wan_connectivity['wan_down_start'].dt.floor('h')
    
    # Get unique properties
    properties = eero_details['MDU Name'].dropna().unique()
    print(f"\n✓ Found {len(properties)} unique properties")
    
    # Connect to database
    print(f"\nConnecting to database: {database_path}")
    conn = sqlite3.connect(database_path)
    
    # Create schema
    create_database_schema(conn)
    
    # Clear existing data
    clear_existing_data(conn)
    
    cursor = conn.cursor()
    
    # Process each property
    print(f"\n{'='*60}")
    print("PROCESSING PROPERTIES")
    print(f"{'='*60}\n")
    
    properties_with_outages = 0
    properties_without_outages = 0
    total_outages_processed = 0
    
    for idx, property_name in enumerate(sorted(properties), 1):
        print(f"[{idx}/{len(properties)}] {property_name}")
        
        # Get all networks for this property
        property_networks = eero_details[eero_details['MDU Name'] == property_name]
        network_ids = property_networks['Eero Network ID'].dropna().unique()
        
        print(f"  Networks: {len(network_ids)}")
        
        # Get all outages for these networks
        property_outages = wan_connectivity[wan_connectivity['network_id'].isin(network_ids)]
        
        print(f"  Outages: {len(property_outages)}")
        
        if len(property_outages) == 0:
            print(f"  Status: Skipped (no outages)\n")
            properties_without_outages += 1
            continue
        
        properties_with_outages += 1
        total_outages_processed += len(property_outages)
        
        # Insert property
        cursor.execute("""
            INSERT INTO properties (property_name, total_networks, total_outages, last_updated)
            VALUES (?, ?, ?, ?)
        """, (property_name, len(network_ids), len(property_outages), datetime.now()))
        
        property_id = cursor.lastrowid
        
        # Insert networks
        network_info = property_networks[['Eero Network ID', 'Street Address', 'Subloc', 'Customer Name']].drop_duplicates()
        
        for _, network_row in network_info.iterrows():
            network_id = network_row['Eero Network ID']
            network_outages = property_outages[property_outages['network_id'] == network_id]
            
            cursor.execute("""
                INSERT OR REPLACE INTO networks 
                (network_id, property_id, street_address, subloc, customer_name, total_outages)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                int(network_id),
                property_id,
                network_row['Street Address'],
                network_row['Subloc'],
                network_row['Customer Name'],
                len(network_outages)
            ))
        
        # Insert raw outages
        for _, outage in property_outages.iterrows():
            cursor.execute("""
                INSERT INTO outages (network_id, wan_down_start, wan_down_end, duration, reason)
                VALUES (?, ?, ?, ?, ?)
            """, (
                int(outage['network_id']),
                str(outage['wan_down_start']),
                str(outage['wan_down_end']),
                outage['duration'],
                outage['reason']
            ))
        
        # Calculate and insert aggregated hourly outages
        aggregated_outages = property_outages.groupby('outage_hour').size().reset_index(name='total_outage_count')
        
        for _, agg_row in aggregated_outages.iterrows():
            cursor.execute("""
                INSERT INTO property_hourly_outages (property_id, outage_hour, total_outage_count)
                VALUES (?, ?, ?)
            """, (property_id, str(agg_row['outage_hour']), agg_row['total_outage_count']))
        
        # Calculate and insert network hourly outages
        hourly_outages = property_outages.groupby(['network_id', 'outage_hour']).size().reset_index(name='outage_count')
        
        for _, hour_row in hourly_outages.iterrows():
            cursor.execute("""
                INSERT INTO network_hourly_outages (network_id, outage_hour, outage_count)
                VALUES (?, ?, ?)
            """, (int(hour_row['network_id']), str(hour_row['outage_hour']), hour_row['outage_count']))
        
        conn.commit()
        print(f"  Status: ✓ Data inserted into database\n")
    
    # Print summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"Total Properties: {len(properties)}")
    print(f"Properties with Outages: {properties_with_outages}")
    print(f"Properties without Outages: {properties_without_outages}")
    print(f"Total Outages Processed: {total_outages_processed:,}")
    print(f"Database: {database_path}")
    print(f"{'='*60}\n")
    
    # Print some sample queries
    print("Sample Database Queries:")
    print("-" * 60)
    
    cursor.execute("SELECT COUNT(*) FROM properties WHERE total_outages > 0")
    count = cursor.fetchone()[0]
    print(f"Properties with outages in DB: {count}")
    
    cursor.execute("SELECT COUNT(*) FROM networks")
    count = cursor.fetchone()[0]
    print(f"Total networks in DB: {count}")
    
    cursor.execute("SELECT COUNT(*) FROM outages")
    count = cursor.fetchone()[0]
    print(f"Total outage records in DB: {count}")
    
    print("-" * 60)
    
    conn.close()
    
    return properties_with_outages


def main():
    """Main entry point for the script."""
    # Check virtual environment
    check_venv()
    
    parser = argparse.ArgumentParser(
        description='Process property outages from WAN connectivity and Eero discovery data into a database.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --connectivity-file wan_connectivity.csv --discovery-file eero_discovery.csv
  
  %(prog)s \\
    --connectivity-file /path/to/wan_connectivity-2025-11-06.csv \\
    --discovery-file /path/to/Eero_Discovery_Details.csv \\
    --database ./output/outages.db
        """
    )
    
    parser.add_argument(
        '--connectivity-file',
        required=True,
        help='Path to the WAN connectivity CSV file (contains outage data)'
    )
    
    parser.add_argument(
        '--discovery-file',
        required=True,
        help='Path to the Eero discovery details CSV file (contains property and network data)'
    )
    
    parser.add_argument(
        '--database',
        default='./output/outages.db',
        help='Path to the SQLite database file (default: ./output/outages.db)'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )
    
    args = parser.parse_args()
    
    # Validate input files
    validate_file(args.connectivity_file, "Connectivity")
    validate_file(args.discovery_file, "Discovery")
    
    # Create output directory if needed
    db_dir = os.path.dirname(args.database)
    if db_dir and not os.path.exists(db_dir):
        os.makedirs(db_dir, exist_ok=True)
    
    # Process the data
    try:
        num_properties = process_outages_to_db(
            args.connectivity_file,
            args.discovery_file,
            args.database
        )
        
        print(f"\n✓ SUCCESS: Processed {num_properties} properties into database")
        print(f"✓ Database ready for web application: {args.database}")
        sys.exit(0)
        
    except KeyboardInterrupt:
        print("\n\n✗ Process interrupted by user")
        sys.exit(130)
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
