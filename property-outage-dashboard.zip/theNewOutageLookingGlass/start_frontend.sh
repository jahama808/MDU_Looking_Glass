#!/bin/bash
# Start React Frontend Development Server

echo "Starting React Frontend..."
echo "Frontend will be available at: http://localhost:5173"
echo ""

cd frontend
npm run dev
