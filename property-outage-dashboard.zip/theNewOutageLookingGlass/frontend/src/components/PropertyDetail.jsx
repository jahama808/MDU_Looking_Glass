import { useState, useEffect } from 'react'
import axios from 'axios'
import { useParams, Link } from 'react-router-dom'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import './PropertyDetail.css'

function PropertyDetail() {
  const { id } = useParams()
  const [property, setProperty] = useState(null)
  const [hourlyData, setHourlyData] = useState([])
  const [networks, setNetworks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchPropertyData()
  }, [id])

  const fetchPropertyData = async () => {
    try {
      setLoading(true)
      const [propertyRes, hourlyRes, networksRes] = await Promise.all([
        axios.get(`/api/property/${id}`),
        axios.get(`/api/property/${id}/hourly`),
        axios.get(`/api/property/${id}/networks`)
      ])

      setProperty(propertyRes.data.property)

      // Format hourly data for chart
      const formattedHourly = hourlyRes.data.map(item => ({
        time: new Date(item.outage_hour).toLocaleString('en-US', {
          month: 'short',
          day: 'numeric',
          hour: '2-digit'
        }),
        outages: item.total_outage_count
      }))
      setHourlyData(formattedHourly)

      setNetworks(networksRes.data)
      setError(null)
    } catch (err) {
      setError('Failed to fetch property details. Make sure the Flask API server is running.')
      console.error('Error fetching property data:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="loading">Loading property details...</div>
  }

  if (error) {
    return <div className="error">{error}</div>
  }

  if (!property) {
    return <div className="error">Property not found</div>
  }

  return (
    <div className="property-detail">
      <div className="breadcrumb">
        <Link to="/properties">← Back to Properties</Link>
      </div>

      <div className="property-header">
        <h1>{property.property_name}</h1>
        <div className="property-summary">
          <div className="summary-item">
            <span className="label">Total Networks:</span>
            <span className="value">{property.total_networks}</span>
          </div>
          <div className="summary-item">
            <span className="label">Total Outages:</span>
            <span className="value">{property.total_outages}</span>
          </div>
          {property.last_updated && (
            <div className="summary-item">
              <span className="label">Last Updated:</span>
              <span className="value">{new Date(property.last_updated).toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>

      {hourlyData.length > 0 && (
        <div className="chart-section">
          <h2>Hourly Outage Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis
                dataKey="time"
                angle={-45}
                textAnchor="end"
                height={80}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line
                type="monotone"
                dataKey="outages"
                stroke="#8884d8"
                strokeWidth={2}
                name="Outages"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="networks-section">
        <h2>Networks ({networks.length})</h2>
        {networks.length > 0 ? (
          <div className="networks-table">
            <table>
              <thead>
                <tr>
                  <th>Network ID</th>
                  <th>Address</th>
                  <th>Unit</th>
                  <th>Customer</th>
                  <th>Outages</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {networks.map((network) => (
                  <tr key={network.network_id}>
                    <td>{network.network_id}</td>
                    <td>{network.street_address || 'N/A'}</td>
                    <td>{network.subloc || 'N/A'}</td>
                    <td>{network.customer_name || 'N/A'}</td>
                    <td className="outage-count">{network.total_outages}</td>
                    <td>
                      <Link to={`/network/${network.network_id}`} className="btn btn-small">
                        View Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p>No networks found for this property.</p>
        )}
      </div>
    </div>
  )
}

export default PropertyDetail
