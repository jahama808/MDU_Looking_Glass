import { useState, useEffect } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import './Dashboard.css'

function Dashboard() {
  const [stats, setStats] = useState(null)
  const [propertyWideOutages, setPropertyWideOutages] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      setLoading(true)
      const [statsRes, outagesRes] = await Promise.all([
        axios.get('/api/stats'),
        axios.get('/api/property-wide-outages')
      ])
      setStats(statsRes.data)
      setPropertyWideOutages(outagesRes.data)
      setError(null)
    } catch (err) {
      setError('Failed to fetch statistics. Make sure the Flask API server is running.')
      console.error('Error fetching stats:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="loading">Loading statistics...</div>
  }

  if (error) {
    return <div className="error">{error}</div>
  }

  return (
    <div className="dashboard">
      <h1>Outage Statistics Dashboard</h1>

      {propertyWideOutages && propertyWideOutages.has_property_wide_outages && (
        <div className="alert alert-critical">
          <div className="alert-header">
            <span className="alert-icon">⚠️</span>
            <h2>Property-Wide Outage Alert</h2>
          </div>
          <div className="alert-content">
            <p>
              <strong>{propertyWideOutages.count}</strong> {propertyWideOutages.count === 1 ? 'property has' : 'properties have'} experienced
              property-wide outages in the past 24 hours (≥90% of networks affected in a single hour).
            </p>
            <div className="affected-properties">
              {propertyWideOutages.properties.map((property) => (
                <Link
                  key={property.property_id}
                  to={`/property/${property.property_id}`}
                  className="property-outage-card"
                >
                  <div className="property-outage-name">{property.property_name}</div>
                  <div className="property-outage-details">
                    <span className="outage-time">
                      {new Date(property.outage_hour).toLocaleString()}
                    </span>
                    <span className="outage-stat">
                      {property.outage_count} / {property.total_networks} networks ({property.outage_percentage}%)
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {propertyWideOutages && !propertyWideOutages.has_property_wide_outages && (
        <div className="alert alert-success">
          <div className="alert-header">
            <span className="alert-icon">✓</span>
            <h2>No Property-Wide Outages</h2>
          </div>
          <p>No properties have experienced property-wide outages in the past 24 hours.</p>
        </div>
      )}

      <div className="stats-grid">
        <div className="stat-card">
          <h3>Properties with Outages</h3>
          <div className="stat-value">{stats.properties_with_outages}</div>
        </div>

        <div className="stat-card">
          <h3>Total Outages</h3>
          <div className="stat-value">{stats.total_outages}</div>
        </div>

        <div className="stat-card">
          <h3>Total Networks</h3>
          <div className="stat-value">{stats.total_networks}</div>
        </div>

        <div className="stat-card">
          <h3>Networks with Outages</h3>
          <div className="stat-value">{stats.networks_with_outages}</div>
        </div>
      </div>

      {stats.top_property && (
        <div className="top-property">
          <h2>Property with Most Outages</h2>
          <div className="highlight-card">
            <h3>{stats.top_property.name}</h3>
            <p>{stats.top_property.outages} outages</p>
          </div>
        </div>
      )}

      {stats.outage_reasons && Object.keys(stats.outage_reasons).length > 0 && (
        <div className="outage-reasons">
          <h2>Outage Reasons Breakdown</h2>
          <div className="reasons-grid">
            {Object.entries(stats.outage_reasons).map(([reason, count]) => (
              <div key={reason} className="reason-card">
                <div className="reason-name">{reason || 'UNKNOWN'}</div>
                <div className="reason-count">{count}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="actions">
        <Link to="/properties" className="btn btn-primary">
          View All Properties
        </Link>
      </div>
    </div>
  )
}

export default Dashboard
