#!/usr/bin/env python3
"""
Simple Flask API for Property Outage Database

This provides a REST API to query the outage database.

Install dependencies:
    pip install flask flask-cors

Run the server:
    python api_server.py

API will be available at http://localhost:5000
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sqlite3
import os
import sys
from datetime import datetime, timedelta


# Check if running in virtual environment
def check_venv():
    """Check if script is running in a virtual environment."""
    if not (hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)):
        print("⚠️  WARNING: Not running in a virtual environment!")
        print("   Flask and dependencies may not be available.")
        print("   Run: source venv/bin/activate  (or venv\\Scripts\\activate on Windows)")
        print()
        sys.exit(1)


# Run check before creating app
check_venv()

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Database configuration
DATABASE = os.environ.get('OUTAGES_DB', './output/outages.db')


def get_db_connection():
    """Create a database connection."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # Return rows as dictionaries
    return conn


@app.route('/')
def index():
    """API documentation."""
    return jsonify({
        'name': 'Property Outage API',
        'version': '1.0.0',
        'endpoints': {
            'GET /api/properties': 'Get all properties with outages',
            'GET /api/property/<id>': 'Get property details',
            'GET /api/property/<id>/hourly': 'Get hourly outage data for property',
            'GET /api/property/<id>/networks': 'Get networks for property',
            'GET /api/network/<id>': 'Get network details',
            'GET /api/network/<id>/hourly': 'Get hourly outage data for network',
            'GET /api/xpon-shelves': 'Get all xPON shelves',
            'GET /api/xpon-shelf/<id>': 'Get xPON shelf details and associated properties',
            'GET /api/7x50s': 'Get all 7x50 routers',
            'GET /api/7x50/<id>': 'Get 7x50 router details and associated properties',
            'GET /api/property-wide-outages': 'Get properties with property-wide outages in last 24 hours',
            'GET /api/stats': 'Get overall statistics'
        }
    })


@app.route('/api/properties')
def get_properties():
    """Get all properties with outages."""
    conn = get_db_connection()
    properties = conn.execute("""
        SELECT property_id, property_name, total_networks, total_outages, last_updated
        FROM properties 
        WHERE total_outages > 0
        ORDER BY total_outages DESC
    """).fetchall()
    conn.close()
    
    return jsonify([dict(p) for p in properties])


@app.route('/api/property/<int:property_id>')
def get_property(property_id):
    """Get detailed information about a specific property."""
    conn = get_db_connection()
    
    # Get property info
    property_info = conn.execute("""
        SELECT property_id, property_name, total_networks, total_outages, last_updated
        FROM properties 
        WHERE property_id = ?
    """, (property_id,)).fetchone()
    
    if not property_info:
        conn.close()
        return jsonify({'error': 'Property not found'}), 404
    
    # Get top networks
    top_networks = conn.execute("""
        SELECT network_id, street_address, subloc, total_outages
        FROM networks
        WHERE property_id = ?
        AND total_outages > 0
        ORDER BY total_outages DESC
        LIMIT 5
    """, (property_id,)).fetchall()
    
    conn.close()
    
    return jsonify({
        'property': dict(property_info),
        'top_networks': [dict(n) for n in top_networks]
    })


@app.route('/api/property/<int:property_id>/hourly')
def get_property_hourly(property_id):
    """Get hourly outage data for a property."""
    conn = get_db_connection()
    
    hourly = conn.execute("""
        SELECT outage_hour, total_outage_count
        FROM property_hourly_outages
        WHERE property_id = ?
        ORDER BY outage_hour
    """, (property_id,)).fetchall()
    
    conn.close()
    
    return jsonify([dict(h) for h in hourly])


@app.route('/api/property/<int:property_id>/networks')
def get_property_networks(property_id):
    """Get all networks for a property."""
    conn = get_db_connection()
    
    networks = conn.execute("""
        SELECT network_id, street_address, subloc, customer_name, total_outages
        FROM networks
        WHERE property_id = ?
        ORDER BY total_outages DESC
    """, (property_id,)).fetchall()
    
    conn.close()
    
    return jsonify([dict(n) for n in networks])


@app.route('/api/network/<int:network_id>')
def get_network(network_id):
    """Get detailed information about a specific network."""
    conn = get_db_connection()
    
    # Get network info
    network_info = conn.execute("""
        SELECT n.network_id, n.street_address, n.subloc, n.customer_name, 
               n.total_outages, p.property_name
        FROM networks n
        JOIN properties p ON n.property_id = p.property_id
        WHERE n.network_id = ?
    """, (network_id,)).fetchone()
    
    if not network_info:
        conn.close()
        return jsonify({'error': 'Network not found'}), 404
    
    conn.close()
    
    return jsonify(dict(network_info))


@app.route('/api/network/<int:network_id>/hourly')
def get_network_hourly(network_id):
    """Get hourly outage data for a network."""
    conn = get_db_connection()
    
    hourly = conn.execute("""
        SELECT outage_hour, outage_count
        FROM network_hourly_outages
        WHERE network_id = ?
        ORDER BY outage_hour
    """, (network_id,)).fetchall()
    
    conn.close()
    
    return jsonify([dict(h) for h in hourly])


@app.route('/api/stats')
def get_stats():
    """Get overall statistics."""
    conn = get_db_connection()
    
    stats = {}
    
    # Total properties with outages
    result = conn.execute("SELECT COUNT(*) FROM properties WHERE total_outages > 0").fetchone()
    stats['properties_with_outages'] = result[0]
    
    # Total outages
    result = conn.execute("SELECT SUM(total_outages) FROM properties").fetchone()
    stats['total_outages'] = result[0] or 0
    
    # Total networks
    result = conn.execute("SELECT COUNT(*) FROM networks").fetchone()
    stats['total_networks'] = result[0]
    
    # Networks with outages
    result = conn.execute("SELECT COUNT(*) FROM networks WHERE total_outages > 0").fetchone()
    stats['networks_with_outages'] = result[0]
    
    # Outage reasons breakdown
    reasons = conn.execute("""
        SELECT reason, COUNT(*) as count
        FROM outages
        GROUP BY reason
        ORDER BY count DESC
    """).fetchall()
    stats['outage_reasons'] = {(r['reason'] or 'UNKNOWN'): r['count'] for r in reasons}
    
    # Property with most outages
    top_property = conn.execute("""
        SELECT property_name, total_outages
        FROM properties
        ORDER BY total_outages DESC
        LIMIT 1
    """).fetchone()
    if top_property:
        stats['top_property'] = {
            'name': top_property['property_name'],
            'outages': top_property['total_outages']
        }
    
    conn.close()
    
    return jsonify(stats)


@app.route('/api/search')
def search():
    """Search for properties by name."""
    query = request.args.get('q', '').strip()
    
    if not query:
        return jsonify({'error': 'Query parameter "q" is required'}), 400
    
    conn = get_db_connection()
    
    properties = conn.execute("""
        SELECT property_id, property_name, total_networks, total_outages
        FROM properties
        WHERE property_name LIKE ?
        ORDER BY total_outages DESC
    """, (f'%{query}%',)).fetchall()
    
    conn.close()
    
    return jsonify([dict(p) for p in properties])


@app.route('/api/xpon-shelves')
def get_xpon_shelves():
    """Get all xPON shelves with statistics."""
    conn = get_db_connection()

    shelves = conn.execute("""
        SELECT shelf_id, shelf_name, total_properties, total_networks
        FROM xpon_shelves
        ORDER BY total_properties DESC, shelf_name
    """).fetchall()

    conn.close()

    return jsonify([dict(s) for s in shelves])


@app.route('/api/xpon-shelf/<int:shelf_id>')
def get_xpon_shelf(shelf_id):
    """Get detailed information about a specific xPON shelf."""
    conn = get_db_connection()

    # Get shelf info
    shelf_info = conn.execute("""
        SELECT shelf_id, shelf_name, total_properties, total_networks
        FROM xpon_shelves
        WHERE shelf_id = ?
    """, (shelf_id,)).fetchone()

    if not shelf_info:
        conn.close()
        return jsonify({'error': 'xPON shelf not found'}), 404

    # Get associated properties
    properties = conn.execute("""
        SELECT p.property_id, p.property_name, p.total_outages, pxs.network_count
        FROM properties p
        JOIN property_xpon_shelves pxs ON p.property_id = pxs.property_id
        WHERE pxs.shelf_id = ?
        ORDER BY p.total_outages DESC
    """, (shelf_id,)).fetchall()

    conn.close()

    return jsonify({
        'shelf': dict(shelf_info),
        'properties': [dict(p) for p in properties]
    })


@app.route('/api/7x50s')
def get_7x50s():
    """Get all 7x50 routers with statistics."""
    conn = get_db_connection()

    routers = conn.execute("""
        SELECT router_id, router_name, total_properties, total_networks
        FROM router_7x50s
        ORDER BY total_properties DESC, router_name
    """).fetchall()

    conn.close()

    return jsonify([dict(r) for r in routers])


@app.route('/api/7x50/<int:router_id>')
def get_7x50(router_id):
    """Get detailed information about a specific 7x50 router."""
    conn = get_db_connection()

    # Get router info
    router_info = conn.execute("""
        SELECT router_id, router_name, total_properties, total_networks
        FROM router_7x50s
        WHERE router_id = ?
    """, (router_id,)).fetchone()

    if not router_info:
        conn.close()
        return jsonify({'error': '7x50 router not found'}), 404

    # Get associated properties
    properties = conn.execute("""
        SELECT p.property_id, p.property_name, p.total_outages, p7.network_count
        FROM properties p
        JOIN property_7x50s p7 ON p.property_id = p7.property_id
        WHERE p7.router_id = ?
        ORDER BY p.total_outages DESC
    """, (router_id,)).fetchall()

    conn.close()

    return jsonify({
        'router': dict(router_info),
        'properties': [dict(p) for p in properties]
    })


@app.route('/api/property-wide-outages')
def get_property_wide_outages():
    """
    Get properties that experienced property-wide outages in the last 24 hours.
    A property-wide outage is when outages in a 1-hour period exceed 90% of total networks.
    """
    conn = get_db_connection()

    # Calculate 24 hours ago
    twenty_four_hours_ago = datetime.now() - timedelta(hours=24)

    # Query for property-wide outages
    # Join properties with hourly outages and check if any hour had >= 90% outages
    property_wide_outages = conn.execute("""
        SELECT
            p.property_id,
            p.property_name,
            p.total_networks,
            pho.outage_hour,
            pho.total_outage_count,
            ROUND(CAST(pho.total_outage_count AS FLOAT) / p.total_networks * 100, 1) as outage_percentage
        FROM properties p
        JOIN property_hourly_outages pho ON p.property_id = pho.property_id
        WHERE pho.outage_hour >= ?
        AND CAST(pho.total_outage_count AS FLOAT) / p.total_networks >= 0.9
        ORDER BY pho.outage_hour DESC, outage_percentage DESC
    """, (twenty_four_hours_ago.isoformat(),)).fetchall()

    conn.close()

    # Format results
    results = []
    seen_properties = set()

    for row in property_wide_outages:
        property_id = row['property_id']
        if property_id not in seen_properties:
            seen_properties.add(property_id)
            results.append({
                'property_id': property_id,
                'property_name': row['property_name'],
                'total_networks': row['total_networks'],
                'outage_hour': row['outage_hour'],
                'outage_count': row['total_outage_count'],
                'outage_percentage': row['outage_percentage']
            })

    return jsonify({
        'has_property_wide_outages': len(results) > 0,
        'count': len(results),
        'properties': results
    })


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    # Check if database exists
    if not os.path.exists(DATABASE):
        print(f"Error: Database file not found: {DATABASE}")
        print("Please run process_property_outages_db.py first to create the database.")
        exit(1)
    
    print(f"Starting API server...")
    print(f"Database: {DATABASE}")
    print(f"API will be available at: http://localhost:5000")
    print(f"API documentation at: http://localhost:5000/")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
